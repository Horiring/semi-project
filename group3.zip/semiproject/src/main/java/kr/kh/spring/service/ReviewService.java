package kr.kh.spring.service;

public interface ReviewService {

}
