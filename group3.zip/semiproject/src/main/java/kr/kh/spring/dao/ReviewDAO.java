package kr.kh.spring.dao;

public interface ReviewDAO {

}
